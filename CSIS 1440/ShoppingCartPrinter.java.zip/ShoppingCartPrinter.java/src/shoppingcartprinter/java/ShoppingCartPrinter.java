// CSIS 1400
// Program: shoppingcartprinter
// Name: Phuc Hoang


package shoppingcartprinter.java;
import java.util.Scanner;
public class ShoppingCartPrinter
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String nameItem;
        int priceItem;
        int numItem;
        
        ItemToPurchase item1 = new ItemToPurchase();
        ItemToPurchase item2 = new ItemToPurchase();
        
        
        //getting user input for item 1
        System.out.println("Item 1");
        System.out.println("Enter the item name:");
        nameItem = sc.nextLine();
        System.out.println("Enter the item price:");
        priceItem = sc.nextInt();
        System.out.println("Enter the item quantity:");
        numItem = sc.nextInt();
        
        //calling the method for item 1
        item1.setName(nameItem);
        item1.setPrice(priceItem);
        item1.setQuantity(numItem);
        
        //getting user input for item 2
        sc.nextLine();
        System.out.println("Item 2");
        System.out.println("Enter the item name:");
        nameItem = sc.nextLine();
        System.out.println("Enter the item price:");
        priceItem = sc.nextInt();
        System.out.println("Enter the item quantity:");
        numItem = sc.nextInt();
        
        //calling the methods for item2
        item2.setName(nameItem);
        item2.setPrice(priceItem);
        item2.setQuantity(numItem);
        
        //Print out the information
        System.out.println("TOTAL COST");
        System.out.println(item1.getName() + " " + item1.getQuantity() + " @ $" + item1.getPrice() + " = $" + (item1.getPrice() * item1.getQuantity()));
        System.out.println(item2.getName() + " " + item2.getQuantity() + " @ $" + item2.getPrice() + " = $" + (item2.getPrice() * item2.getQuantity()));
        System.out.println("");
        System.out.println("");
        System.out.println(("Total: $" + ((item1.getPrice() * item1.getQuantity()) + (item2.getPrice() * item2.getQuantity()))));
        
    }
    
}
